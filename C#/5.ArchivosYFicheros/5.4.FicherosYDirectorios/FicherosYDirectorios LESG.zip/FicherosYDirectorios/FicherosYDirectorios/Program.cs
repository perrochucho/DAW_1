﻿using System;
using System.IO;

namespace FicherosYDirectorios
{
    class Program
    {
        static void Main(string[] args)
        {
            int respuesta = 1;
            while (respuesta != 0)
            {
                Console.Clear();
                Console.WriteLine("Eladio te da la bienvenida a:");
                Console.WriteLine();
                Console.WriteLine("     RELACION DE EJERCICIOS DE FICHEROS");
                Console.WriteLine("                    Parte IV");
                Console.WriteLine();
                Console.WriteLine("     ---------FICHEROS Y DIRECTORIOS---------");
                Console.WriteLine();
                Console.WriteLine("Introduce a continuación el numero que quieres");
                Console.WriteLine();
                Console.WriteLine("1- CuantosFicheros");
                Console.WriteLine("2- CuantosFicherosPro");
                Console.WriteLine("3- CreaBackup");
                Console.WriteLine("4- RenombraMasivo");
                Console.WriteLine("5- CuentaLineasFicheros");
                Console.WriteLine("6- FicheroMasGrande");
                Console.WriteLine();
                Console.WriteLine("Introduce un 0 en cualquier momento para salir del menú");

                respuesta = int.Parse(Console.ReadLine());
                Console.WriteLine();
                Console.Write("Numero introducido: " + respuesta);


                switch (respuesta)
                {
                    case 1:
                        {

                            Console.WriteLine();
                            Console.WriteLine("Que extension quieres comprobar?");
                            string ext = Console.ReadLine();
                            Console.WriteLine();
                            Console.WriteLine("El numero de archivos con la extension " + ext + " es: " + CuantosFicheros(ext)); 
                            Console.WriteLine();
                            Console.WriteLine("Has terminado ya? Pulsa cualquier tecla para acabar");
                            Console.ReadLine();
                        }
                        break;
                    case 2:
                        {
                            Console.WriteLine();
                            string carpeta = Console.ReadLine();
                            Console.WriteLine("Que extension quieres comprobar");
                            string ext = Console.ReadLine();
                            Console.WriteLine();
                            Console.WriteLine(CuantosFicherosPro(ext, carpeta));
                            Console.WriteLine();
                            Console.WriteLine("Has terminado ya? Pulsa cualquier tecla para acabar");                            
                            Console.ReadLine();
                        }
                        break;
                    case 3:
                        {
                            Console.WriteLine();
                            Console.WriteLine("Di el nombre del fichero");
                            string filename = Console.ReadLine();
                            CreaBackup(filename);
                            Console.WriteLine();
                            Console.WriteLine("Has terminado ya? Pulsa cualquier tecla para acabar");
                            Console.ReadLine();
                            //Console.ReadLine();
                        }
                        break;
                    case 4:
                        {
                            Console.WriteLine();
                            Console.WriteLine("Introduce la extension que quieres cambiar");
                            string extorigen = Console.ReadLine();
                            Console.WriteLine("Introduce la extension HACIA la que quieres cambiar");
                            string extdestino = Console.ReadLine();
                            RenombraMasivo(extorigen, extdestino);
                            Console.WriteLine();
                            Console.WriteLine("Has terminado ya? Pulsa cualquier tecla para acabar");
                            Console.ReadLine();
                        }
                        break;
                    case 5:
                        {
                            Console.WriteLine();
                            Console.WriteLine("Introduce la extension que quieres comprobar");
                            string ext = Console.ReadLine();
                            Console.WriteLine(CuentaLineasFicheros(ext));
                            Console.WriteLine();
                            Console.WriteLine("Has terminado ya? Pulsa cualquier tecla para acabar");
                            Console.ReadLine();
                        }
                        break;
                    case 6:
                        {
                            Console.WriteLine();
                            Console.WriteLine("El fichero mas grande es:" + FicheroMasGrande());
                            Console.WriteLine();
                            Console.WriteLine("Has terminado ya? Pulsa cualquier tecla para acabar");
                            Console.ReadLine();
                        }
                        break;                        
                    default:
                        break;

                }
                while (respuesta < 0 || respuesta > 8)
                {
                    Console.Clear();
                    Console.WriteLine("Eladio te da la bienvenida a:");
                    Console.WriteLine();
                    Console.WriteLine("     RELACION DE EJERCICIOS DE FICHEROS");
                    Console.WriteLine("                    Parte IV");
                    Console.WriteLine();
                    Console.WriteLine("     ---------FICHEROS Y DIRECTORIOS---------");
                    Console.WriteLine();
                    Console.WriteLine("Introduce a continuación el numero que quieres");
                    Console.WriteLine();
                    Console.WriteLine("1- CuantosFicheros");
                    Console.WriteLine("2- CuantosFicherosPro");
                    Console.WriteLine("3- CreaBackup");
                    Console.WriteLine("4- RenombraMasivo");
                    Console.WriteLine("5- CuentaLineasFicheros");
                    Console.WriteLine("6- FicheroMasGrande");
                    Console.WriteLine();
                    Console.WriteLine("Introduce un 0 en cualquier momento para salir del menú");

                    respuesta = int.Parse(Console.ReadLine());
                    Console.WriteLine();
                    Console.Write("Numero introducido: " + respuesta);
                    Console.WriteLine();
                }
            }
        }
        static int CuantosFicheros (string ext)
        {
            int total = 0;
            //Path.GetExtension(".");
            string carpeta = Directory.GetCurrentDirectory();
            string[] ficheros = Directory.GetFiles(carpeta);
            for (int i = 0; i < ficheros.Length; i++)                
            {
                string extension = Path.GetExtension(ficheros[i]);
                if (extension == ext)
                {
                    total++;
                }
            }
            return total;
        }
        static int CuantosFicherosPro (string ext, string carpeta)
        {
            int total = 0;
            string[] ficheros = Directory.GetFiles(carpeta);

            for (int i = 0; i < ficheros.Length; i++)
            {
                //FileInfo f = new FileInfo(carpeta);
                string extension = Path.GetExtension(ficheros[i]);
                if (extension == ext)
                {
                    total++;
                }
            }
            return total;
        }
        static void CreaBackup (string filename)
        {
            string filename2 = filename + ".bak";                     

             if (File.Exists(filename))
             {
                while(File.Exists(filename2))
                {
                    filename2 = filename2 + ".bak";
                }
                    File.Copy(filename, filename2);                    
             }            
        }
        static void RenombraMasivo (string extorigen, string extdestino)
        {
            string[] ficheros = Directory.GetFiles(".");
            
            for (int i = 0; i < ficheros.Length; i++)
            {                
                string extension = Path.GetExtension(ficheros[i]);
                string nombre1 = ficheros[i];
                string nombre2 = nombre1.Replace(extorigen, extdestino);
                File.Move(nombre1, nombre2);
            }
        }
        static int CuentaLineasFicheros(string ext)
        {
            int lineastotales = 0;
            string diractual = Directory.GetCurrentDirectory();
            string[] ficheros = Directory.GetFiles(diractual);
            string extactual;
            for (int i = 0; i < ficheros.Length; i++)
            {
                extactual = Path.GetExtension(ficheros[i]); 
                if (extactual == ext)
                {
                    lineastotales += File.ReadAllLines(ficheros[i]).Length;
                }
            }
            return lineastotales;
        }
        static string FicheroMasGrande()
        {
            string diractual = Directory.GetCurrentDirectory();
            string[] ficheros = Directory.GetFiles(diractual);
            string resultado = "";
            FileInfo f;
            long maxsize = 0; 
            long size = 0;
            for (int i = 0; i < ficheros.Length; i++)
            {
                f = new FileInfo(ficheros[i]);
                size = f.Length;
                if (size > maxsize)
                {
                    maxsize = size;
                    resultado = f.Name;
                }
            }
                return resultado;
        }
    }
}

