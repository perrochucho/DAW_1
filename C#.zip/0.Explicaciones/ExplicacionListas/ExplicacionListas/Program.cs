﻿using System;
using System.Collections.Generic; 
namespace ExplicacionListas
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Explicaciones

            //Declaramos una lista de nombre "integerlist" con enteros            
            List<int> ol = new List<int>();
            ////Escribe la lista vacia
            //EscribeLista(integerlist);
            ////añadimos a la integerlist un 5, como ahora mismo está vacía se añade en la primera posición, es decir, [0]
            //integerlist.Add(5);
            ////Escribe la lista con lo que tenga
            //EscribeLista(integerlist);
            ////Establece que la posición 0 de la lista, que era un 5, ahora es 10
            //integerlist[0] = 10;
            ////Escribe la lista con lo que tenga
            //EscribeLista(integerlist);
            ////Escribe la posicion 0 de la lista que sigue siendo 10
            //Console.WriteLine(integerlist[0]); 

            ////Ejemplo de bucle infinito
            ////Este bicho añade un elemento a la lista hasta que se llene, pero como el tamaño va sumandose nunca acaba
            ////for (int i = 0; i < integerlist.Count; i++)
            ////{
            ////    integerlist.Add(5);
            ////    Console.WriteLine(integerlist[i]);
            ////}

            ////// Insertar cosas en una lista
            //////Add = Añade un elemento al final de la lista
            ////integerlist.Add(99);
            //////Insert = Añade un elemento a la posicion que le digas
            ////integerlist.Insert(0, -99); //Inserta el 99 en la posición 0 (al principio)
            //////AddRange y InsertRange
            //int[] array = { 11, 12, 13 };
            //ol.AddRange(array);
            //EscribeLista(ol);

            ////List<char> charlist = new List<char>();
            //////charlist.AddRange("patata");
            ////List<int> integerlist2 = new List<int>();
            ////integerlist.RemoveRange(0, integerlist.Count);
            ////integerlist2.Add(5);
            ////integerlist2.Insert(1, 10);
            ////integerlist.AddRange(integerlist2);
            ////EscribeLista(integerlist);

            //// ------------------ Borrar cosas de una lista -----------------
            //ol.RemoveAt(0); //RemoveAt borra el elemento que esté en la posición que le pasas
            //EscribeLista(ol);
            ////Remove borra el elemento que le pasas (pero solamente uno) (empezando por el principio, claro)
            //ol.Remove(11);
            //EscribeLista(ol);
            ////RemoveRange te borra un rango
            //ol.RemoveRange(0, ol.Count); // 0 posicion en la que empieza, ol.Count numero de posiciones que quiero quitar
            //                             // (no hasta esa posición)
            //                             //RemoveAll
            //ol.RemoveAll(p => p == 10); //Borrame la variable p donde la p sea igual a 10 (Similar a hacerlo con un for
            //EscribeLista(ol);

            //Clear lo borra to

            // ---------------- Buscar cosas en una lista  -----------------------

            MeteLista110(ol);
            //Contains
            if (ol.Contains(12))
            {
                Console.WriteLine("Está");
            }
            else
            {
                Console.WriteLine("No está");
            }
            //IndexOf
            Console.WriteLine(ol.IndexOf(12));

            //Find te devuelve el primer elemento que cumple la condición

            //FindIndex te devuelve la posición del primer elemento que cumple la condición
            Console.WriteLine(ol.Find(p => p % 2 == 0));

            //EscribeLista(ol.FindAll(p => p < 5));
            ol.Clear();
            for (int i = 1; i <= 5; i++)
            {
                ol.Add(i);
            }
            EscribeLista(ol);
            Console.WriteLine("Numeros impares = " + ol.FindAll(p => p % 2 == 1).Count);

            // -------------- Otras ----------
            //Reverse le da la vuelta a la lista
            ol.Reverse(); //le da la vuelta a la lista
            EscribeLista(ol);
            ol.Sort(); //Ordena la lista en orden ascendente
            EscribeLista(ol);

            //ToArray nos convierte la lista en un array
            int[] a = ol.ToArray();

            //int[] b = new int[5];
            //ol.CopyTo(5, b, 0, 5);
            //EscribeArray(b);
            //ol.Clear();
            //EscribeLista(ol);
            #endregion
        }
            static void EscribeLista(List<int> ol)
        {
            Console.Write("< ");
            for (int i = 0; i < ol.Count; i++)
            {
                Console.Write(ol[i] + " ");
            }
            Console.WriteLine(">");
        }

        static void MeteLista110(List<int> ol)
        {
            for (int i = 0; i <= 10; i++)
            {
                ol.Add(i);
            }
        }
        static void EscribeArray(int[] array)
        {
            Console.Write("[ ");
            for (int i = 0; i < array.Length - 1; i++)
            {
                Console.Write(array[i] + " ");
            }
            Console.WriteLine("]");
        }

    }
}
