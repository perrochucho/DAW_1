﻿using System;
using System.IO;

namespace ExplicaciónArchivosYFicheros
{
    class Program
    {
        static void Main(string[] args)
        {
            #region 1. FicherosTexto

            ////1 - Abrimos el fichero para escritura = Crear fichero nuevo
            //StreamWriter sw = new StreamWriter("prueba.txt");

            ////2- Escribir cosas en el fichero
            //sw.WriteLine("Hola Don Pepito, Hola Don José");
            //sw.WriteLine("Paso usted ya por mi casa");

            ////3- Cerrar el fichero IMPORTANTE
            //sw.Close();            


            //1 - Abrimos el fichero para lectura

            //StreamReader sr = new StreamReader("prueba.txt");
            ////string linea1 = sr.ReadLine();
            ////Console.WriteLine(linea1);


            ////for (int i = 0; i < 10; i++)
            ////{
            ////    Console.WriteLine(linea1);
            ////}

            //string linea1;
            //while (!sr.EndOfStream)
            //{
            //    linea1 = sr.ReadLine();
            //    Console.WriteLine(linea1);
            //}

            ////Usando funciones con ficheros
            ////EscribeFichero("mifichero.txt");

            //sr.Close();
            #endregion

            #region 2. Ficheros Binarios

            //FileStream fs = new FileStream("binario.bin", FileMode.Create);
            //BinaryWriter bw = new BinaryWriter(fs);
            //bw.Write(1);
            //bw.Write(2);
            //bw.Write(3);
            //bw.Write(4);
            //bw.Write(5);

            //fs.Close();
            //bw.Close();


            FileStream fs = new FileStream("binario.bin", FileMode.Open);
            BinaryReader br = new BinaryReader(fs);

            int n1 = br.ReadInt32();
            Console.WriteLine(n1);


            //while (fs.Position < fs.Length)
            //{
            //    int n = br.ReadInt32();
            //    Console.WriteLine(n);
            //}

            br.Close();
            fs.Close();

            #endregion      



        }
        //static void EscribeFicheroNumRandom10(string fichero)
        //{
        //    StreamWriter sw = new StreamWriter(fichero);

        //    sw.WriteLine("Hola Don Pepito");

        //    sw.Close();
        //}
    }
}
